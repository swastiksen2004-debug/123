import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const zip = new JSZip();

function addDirectoryToZip(dirPath: string, zipFolder: JSZip) {
  const items = fs.readdirSync(dirPath);
  for (const item of items) {
    if (['node_modules', '.git', 'dist', '.cache', 'public'].includes(item)) continue;
    const fullPath = path.join(dirPath, item);
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      const subFolder = zipFolder.folder(item);
      if (subFolder) addDirectoryToZip(fullPath, subFolder);
    } else {
      const content = fs.readFileSync(fullPath);
      zipFolder.file(item, content);
    }
  }
}

async function buildZip() {
  addDirectoryToZip('.', zip);
  const content = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  fs.writeFileSync('./public/kbssn-full-code.zip', content);
  console.log('Successfully created public/kbssn-full-code.zip! Size:', (content.length / 1024).toFixed(1), 'KB');
}

buildZip();
